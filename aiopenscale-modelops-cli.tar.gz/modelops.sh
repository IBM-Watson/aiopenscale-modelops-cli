#!/bin/bash

###############################################################################
# This script is used to execute the main entry point in the Model Ops CLI tool.
#
# To see Usage: modelops.sh --help
#
# (C) Copyright IBM Corp. 2018
###############################################################################

# Verify that java is installed; it is a pre-requisite
verify_java()
{
  if ! [ -x "$(command -v java)" ]; then
    echo 'Error: java is not installed.' >&2
    exit 1
  fi
}

# Verify that curl is installed; it is a pre-requisite for installing
# the IBM Cloud CLI tool
verify_curl()
{
  if ! [ -x "$(command -v curl)" ]; then
    echo 'Error: curl is not installed.' >&2
    exit 1
  fi
}

# Check whether or not both the IBM Cloud CLI and machine-learning plugin
# are installed.  If not, give a warning recommending installation and
# prompting the user if they would like to install.
should_install_ibmcloud_cli_ml=n
prompt_install_ibmcloud_cli_ml()
{
  echo "The IBM Cloud CLI and/or the machine-learning plugin are not installed."
  echo "It is highly recommended that you install the IBM Cloud CLI and the machine-learning plugin, to allow you to better manage the machine learning model lifecycle."
  echo -n "Do you want to install the IBM Cloud CLI and the machine-learning plugin (y/n)? "
  read should_install_ibmcloud_cli_ml
}

install_ibmcloud_cli()
{
  # curl must be installed in order to install IBM Cloud CLI
  verify_curl
  os_name="$(uname -s)"
  if [ "$os_name" = "Darwin" ]; then
    # MacOS
    curl -fsSL https://clis.ng.bluemix.net/install/osx | sh
  else
    # assume it is Linux
    curl -fsSL https://clis.ng.bluemix.net/install/linux | sh
  fi
}

install_ml_plugin()
{
  bx plugin install machine-learning
}

check_ibmcloud_cli_ml()
{
  has_bx=`which bx`
  if [ "$has_bx"x = "x" ]; then
    # bx is not installed, so prompt the user to install
    # it is assumed that if bx is not installed, the machine-learning
    # plugin isn't installed
    prompt_install_ibmcloud_cli_ml
    if [ "$should_install_ibmcloud_cli_ml" != "${should_install_ibmcloud_cli_ml#[Yy]}" ]; then
      install_ibmcloud_cli
      install_ml_plugin
    fi
  else
    # bx is installed, so check whether the machine-learning plugin is installed
    has_ml=`bx plugin list | grep machine-learning`
    if [ "$has_ml"x = "x" ]; then
      prompt_install_ibmcloud_cli_ml
      if [ "$should_install_ibmcloud_cli_ml" != "${should_install_ibmcloud_cli_ml#[Yy]}" ]; then
        install_ml_plugin
      fi
    fi
  fi
}

###################
# Entry point below
###################
# Verify that java is installed and do not proceed if it is not
verify_java

# Check whether or not IBM Cloud CLI and the machine-learning plugin are
# installed. If not, ask the user if they would like them installed.
check_ibmcloud_cli_ml

# Call the executable JAR, passing along all options
java -jar model-operation-tasks-cli.jar ${1+"$@"}
